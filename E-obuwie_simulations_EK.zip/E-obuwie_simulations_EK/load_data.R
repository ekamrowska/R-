require(tidyverse)

load_data <- function(.file){

  .path <- 'c:/Users/ekamrowska/Desktop/Zadania - analityk DOC'
  readr::read_delim(file.path(.path, paste0(.file, '.csv')), delim = ';')
}

dispatchAdvices <- load_data("dispatchAdvices")
dispatchAdviceSrc <- load_data("idDispatchAdviceSrc")
logDispatchAdvices <- load_data("logDispatchAdvices")
orders <- load_data("orders")

### TASK.1
temp <- orders %>%
  filter(orderState != 1) %>%
  left_join(dispatchAdviceSrc, by = 'idOrder') %>%
  left_join(dispatchAdvices, by = 'idDispatchAdvice') %>%
  mutate(diff_h = difftime(creationDate, orderDate, units = "hours")) %>%
  filter(!creationDate %>% is.na())

ANS1a <- temp %>%
  summarise(mean_diff_h = round(mean(diff_h), digits = 0))

ANS1b <- temp %>%
  mutate(interval = ifelse(diff_h < 1, '<1h',
                ifelse(diff_h < 3, '1-3h',
                       ifelse(diff_h < 12, '3-12h',
                              ifelse(diff_h < 24, '12-24h',
                                     ifelse(diff_h < 48, 'do 2 dni',
                                            ifelse(diff_h < 72, 'do 3 dni',
                                                   ifelse(diff_h < 96, 'do 4 dni',
                                                          ifelse(diff_h < 120, 'do 5 dni',
                                                                 ifelse(diff_h < 144, 'do 6 dni', 'powyżej 6 dni')))))))))) %>%
  count(interval) %>%
  mutate(proc_interval = round(n/sum(n)*100, 1))


### TASK.2
temp2 <- orders %>%
  filter(orderState != 1) %>%
  left_join(dispatchAdviceSrc, by = 'idOrder') %>%
  left_join(dispatchAdvices, by = 'idDispatchAdvice')

no_dispatchAdviceNumber <- temp2 %>%
  filter(dispatchAdviceNumber %>% is.na) %>%
  nrow()

## 18.7% zamówień (bedacych w realizacji przez WMS oraz zrealizowane przez WMS) nie posiada awizo wydania.
ANS2a <- round(no_dispatchAdviceNumber/nrow(temp2)*100,1)

ANS2b <- temp2 %>%
  filter(dispatchAdviceNumber %>% is.na) %>%
  mutate(diff_days = difftime(Sys.Date(), orderDate, units = 'days')) %>%
  summarise(mean_diff_days = round(mean(diff_days),0))


### TASK.3
temp3 <- dispatchAdvices %>%
  left_join(logDispatchAdvices %>% filter(logDispatchAdviceState == 3),
            by = c('dispatchAdviceNumber' = 'logDispatchAdviceNumber')) %>%
  filter(!creationDate.y %>% is.na) %>%
  mutate(diff_min = difftime(creationDate.y, creationDate.x, units = 'mins'))

ANS3a <- temp3 %>%
  summarise(mean_diff_mins = round(mean(diff_min),0))

ANS3b <- temp3 %>%
  mutate(interval = ifelse(diff_min < 10, '< 10min',
                           ifelse(diff_min < 30, '< 30min',
                                  ifelse(diff_min < 60, '< 60min',
                                         ifelse(diff_min < 120, '< 120min',
                                                ifelse(diff_min < 180, '< 180min', 'powyżej 3h')))))) %>%
  count(interval) %>%
  mutate(proc_interval = round(n/sum(n)*100,0))

### TASK.4
temp4 <- dispatchAdvices %>%
  left_join(logDispatchAdvices, by = c('dispatchAdviceNumber' = 'logDispatchAdviceNumber'))

no_logDispatchAdvice <- temp4 %>%
  filter(logDispatchAdviceState %>% is.na) %>%
  nrow()

ANS4a <- round(no_logDispatchAdvice/nrow(temp4)*100,0)

ANS4b <- temp4 %>%
  filter(logDispatchAdviceState %>% is.na) %>%
  mutate(diff_days = difftime(Sys.Date(), creationDate.x, units = 'days')) %>%
  summarise(mean_diff_days = round(mean(diff_days),0))

### TASK.5

temp5 <- logDispatchAdvices %>%
  filter(logDispatchAdviceState == 3) %>%
  left_join(dispatchAdvices %>%
              select(idDispatchAdvice, dispatchAdviceNumber),
            by = c('logDispatchAdviceNumber' = 'dispatchAdviceNumber')) %>%
  left_join(dispatchAdviceSrc %>%
              select(idOrder, idDispatchAdvice),
            by = 'idDispatchAdvice') %>%
  left_join(orders, by = 'idOrder') %>%
  filter(logDispatchAdviceState == 3 & orderState != 3)

ANS5 <- round(nrow(temp5)/nrow(logDispatchAdvices %>% filter(logDispatchAdviceState == 3))*100,1)









