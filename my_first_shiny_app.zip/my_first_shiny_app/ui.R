library(shiny)
library(shinyjs)
library(dplyr)
library(PogromcyDanych)
library(ggplot2)

# przygotowanie danych
cars <- auta2012 %>%
  mutate(id = rownames(auta2012) %>% as.integer())

nazwyMarek <- sort(levels(cars$Marka))

# funkcja odświeżająca stronę aplikacji 
jscode <- "shinyjs.refresh = function() { history.go(0); }"

shinyUI(fluidPage(
  useShinyjs(),
  extendShinyjs(text = jscode, functions = c("winprint")),
  tags$head(tags$style(HTML("
                            .well {
                            background-color: #d4ebf2!important;
                            width: 200px;
                            }
                            "))),
  titlePanel("Analiza cen poszczególnych marek i modeli aut osobowych"),
  sidebarLayout(
    sidebarPanel(
      width = 3,
      selectInput("wybranaMarka",
                  label = "Wybierz markę auta do analizy",
                  choices = nazwyMarek,
                  selected = "Isuzu"),
      checkboxInput("liniaTrendu",
                    "Czy zaznaczyć linię trendu?",
                    value = TRUE),
      htmlOutput("listaModeli"),
      actionButton("goButton", "Pokaż dane"),
      p("Naciśnij przycisk aby wyświetlić tabelę w zakładce 'Dane'."),
      actionButton("refresh", "Odśwież"),
      p("Naciśnij przycisk aby odświeżyć stronę aplikacji."),
      tags$button(
        id = 'close',
        type = "button",
        class = "btn action-button",
        onclick = "setTimeout(function(){window.close();},500);",  # close browser
        "Zamknij aplikację"
      )
    ),
    mainPanel(
      tabsetPanel(
        tabPanel("Dane",
                 DT::dataTableOutput('table')),
        tabPanel("Wykres",
                 plotOutput("trend")),
        tabPanel("Model",
         verbatimTextOutput("model"))
      )
    )
  )
))

