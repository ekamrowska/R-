library(shiny)
library(shinyjs)
library(plotly)
library(PogromcyDanych)

cars <- auta2012 %>%
  mutate(id = rownames(auta2012) %>% as.integer())

shinyServer(function(input, output, session) {
  
  observeEvent(input$refresh, {
    js$refresh();
  })
  
  observe({
    if(input$close > 0) stopApp()                            
  })
  
  tylkoWybranaMarka <- reactive({
    cars[cars$Marka == input$wybranaMarka, ]
  })

  output$listaModeli <- renderUI({
    marka <- tylkoWybranaMarka()
    selectInput("modele_aut", "Modele dostępnej marki", as.character(marka$Model))
  })
  
  observeEvent(input$goButton, {
    output$table <- DT::renderDataTable(
      cars)
    
    })

  output$trend = renderPlot({
    marka <- tylkoWybranaMarka()

    pl <- ggplot(marka, aes(id, Cena, size=Rok.produkcji, color=Model)) +
      geom_point() + xlab("Numer samochodu")
    
    if (input$liniaTrendu) {
      pl <- pl + geom_smooth(se=FALSE, method="lm", size=3)
    }
    pl
  })

  output$model = renderPrint({
    marka <- tylkoWybranaMarka()

    summary(lm(Cena~id, marka))
  })
})
