require(tidyverse)
require(DT)

load_data <- function(.file){
  .path <- 'c:/Users/ekamrowska/Desktop/Zadania - analityk DOC'
  readr::read_delim(file.path(.path, paste0(.file, '.csv')), delim = ';')
}

give_barplot <- function(.tab, .subtitle){
  .tab %>% 
    ggplot(aes(x = interval, y = N)) + 
    geom_bar(stat = 'identity', fill = '#00008B') +
    theme_bw() + 
    geom_text(aes(label = proc_interval), color = 'white', position = position_stack(vjust = 0.5), fontface = 'bold') + 
    labs(
      subtitle = .subtitle
    )
}

render_table <- function(.tab){
  .tab %>% DT::datatable(rownames = F, options = list(pageLength = 5))
}

dispatchAdvices <- load_data("dispatchAdvices")
dispatchAdviceSrc <- load_data("idDispatchAdviceSrc")
logDispatchAdvices <- load_data("logDispatchAdvices")
orders <- load_data("orders")