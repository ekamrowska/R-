library(ggplot2)
library(shiny)
library(shinyTime)
library(DT)
library(leaflet)
library(maps)
library(sp)
library(geosphere)
library(DT)
library(plotly)
library(dplyr)
library(gtools)
library(readxl)
library(shinyjs)
library(V8)

jscode <- "shinyjs.refresh = function() { history.go(0); }"

source("deg2radFunction.R")
source("distanceFunction.R")
source("MedianslideFunction.R")

ui <- fluidPage( 
  useShinyjs(),
  extendShinyjs(text = jscode, functions = c("winprint")),
                titlePanel("Wykrywanie anomalii w pozycjonowaniu lokalizatora GPS"),
                sidebarLayout(
                  sidebarPanel(
                    width = 3,
                    h4("Import Danych"),
                    fileInput("file1", "Wybierz plik",
                              accept = c(
                                "text/csv",
                                "text/comma-separated-values,text/plain",
                                ".csv")
                    ),
                    h4("Przetwarzanie danych"),
                    actionButton("button", "Przetwarzaj"),
                    h4("Filtrowanie"),
                    actionButton("button2", "Filtruj"),
                    h4("Działanie algorytmu"),
                    actionButton("button3", "Pokaż wynik algorytmu"),
                    h4("Odświeżanie aplikacji"),
                    actionButton("refresh", "Odśwież")
                  ),
                  
                  mainPanel(
                    navbarPage(
                      title = '',
                      tabPanel('dane', DT::dataTableOutput('tab')),
                      tabPanel('mapa', leafletOutput(
                        "map", width = "1200", height = "800"
                      )),
                      tabPanel("wykresy",
                               fluidRow(
                                 column(12, plotlyOutput("plot1"), height = "1200px"),
                                 column(12, plotlyOutput("plot2"), height = "1200px"),
                                 column(12, plotlyOutput("plot3"), height = "1200px"),
                                 column(12, plotlyOutput("plot4"), height = "1200px"),
                                 column(12, plotlyOutput("plot5"), height = "1200px")
                               ))
                    )
                  )
                ))

server <- function(input, output, session) {
  
  observeEvent(input$refresh, {
    js$refresh();
  })
  
  my_data <- reactive({
    inFile <- input$file1
    if (is.null(inFile))
      return(NULL)
    data <- read.csv(inFile$datapath, sep=';', encoding="UTF-8")

  })
  
  
  output$tab <- DT::renderDataTable({
    
    globalData <<- my_data()
    
  })
  
  observeEvent(input$button, {
    
    TD = globalData
    names(TD)[names(TD) == "Czas.GPS"] <- "Czas_GPS"
    TT <- filter(TD, TD$Azymut != "NA" & TD$GPS > 3)
    TT$Czas_GPS <- as.POSIXct(TT$Czas_GPS, format="%d.%m.%Y %H:%M:%S")
    #TT$Czas_GPS <- as.POSIXct(TT$Czas_GPS, format="%Y-%m-%d %H:%M:%S")
    tab <- select(TT, Czas_GPS, Azymut, Latitude, Longitude, GPS)
    t <- !duplicated(tab$Czas_GPS)
    tab <- tab[t,]
    
    v_sr_pieszy = 0.84 #[m/s]
    v_max_pieszy = 2 #[m/s]
    
    tab <- tab %>% mutate(r_azymut = c(NA, abs(diff(Azymut))))
    
    dystans_gps <- c()
    dystans_gps[1] <- NA
    roznica_azymut <- c()
    
    for (i in seq(nrow(tab))){
      
      roznica_azymut <- c(roznica_azymut, min(tab$r_azymut[i], 360-tab$r_azymut[i]))
      dystans_gps <- c(dystans_gps, round(dystans(tab$Lat[i], tab$Lat[i-1], tab$Lon[i], tab$Lon[i-1]),2))
    }
    
    tab <- tab %>% mutate(roznica_azymut = roznica_azymut,
                          zmiana_azymut = c(NA, abs(diff(roznica_azymut))),
                          roznica_czas = c(NA, as.numeric(diff(Czas_GPS, units="secs"))),
                          dystans_gps = dystans_gps,
                          dop_dystans_pieszy = v_sr_pieszy*roznica_czas,
                          predkosc_gps = round(dystans_gps/roznica_czas, 2))
    
    tab$Czas_GPS <- format(tab$Czas_GPS, "%d.%m.%Y %H:%M:%S")
    
    tab <- tab[,-c(6,7)]
    
    ciagi_azymut <- c()
    ciagi_dystans <- c()
    ciagi_gps <- c()
    ciagi_predkosc <- c()
    procent <- c()
    
    window <- 11
    wu <- window-1
    step <- 1
    
    mediany_gps <- MedianslideFunction(tab$GPS, window, step)
    spots <- seq(from=1, to=(nrow(tab)-wu), by=step)
    
    flagaAzymut = c()
    flagaDystans = c()
    flagaGPS = c()
    flagaPredkosc = c()
    indeks_srodkowy_gps <- c()
    indeks_srodkowy_predkosc <- c()
    srodkowe_gps <- c()
    srodkowe_predkosc <- c()
    stan <- c()
    color <- c()
    
    pom <- rep("NA", (window-1)/2)
    
    for(i in 1:length(spots)){
      
      ciagi_azymut <- c(ciagi_azymut, tab$zmiana_azymut[spots[i]:(spots[i]+wu)])
      procent <- c(procent, sum(tab$zmiana_azymut[spots[i]:(spots[i]+wu)] > 15)/(window)*100)
      procent <- round(procent, digits=0)
      
      if(isTRUE(procent[i] > 60)){flagaAzymut <- c(flagaAzymut, 1)}
      else{flagaAzymut <- c(flagaAzymut, 0)}
      
      ciagi_gps <- c(ciagi_gps, tab$GPS[spots[i]:(spots[i]+wu)])
      indeks_srodkowy_gps <- c(indeks_srodkowy_gps, (length(tab$GPS[spots[i]:(spots[i]+wu)])+1)/2)
      srodkowe_gps <- c(srodkowe_gps, tab$GPS[spots[i]:(spots[i]+wu)][indeks_srodkowy_gps[i]])
      
      if(isTRUE(srodkowe_gps[i] > mediany_gps[i])){flagaGPS <- c(flagaGPS, 1)}
      else{flagaGPS <- c(flagaGPS, 0)}
      
    }
    
    tab <- tab %>% mutate(flagaAzymut = c(pom, flagaAzymut, pom),
                          flagaGPS = c(pom, flagaGPS, pom)
                         )
    
    tab <- tab %>% mutate(klasa1 = ifelse((predkosc_gps < v_max_pieszy) |
                                          (predkosc_gps >= v_max_pieszy & (GPS <= 7 | roznica_czas > 120)) |
                                          (flagaAzymut == 0 & zmiana_azymut >= 90), 'PIE', 'POJ'),
                          klasa2 = ifelse((klasa1 == 'PIE' & (predkosc_gps <= v_sr_pieszy & (GPS < 8 | dystans_gps > dop_dystans_pieszy | zmiana_azymut > 90))) |  
                                          (klasa1 == 'PIE' & (zmiana_azymut == 0 & (predkosc_gps <= 1 | GPS <= 7))) | 
                                          (klasa1 == 'PIE' & roznica_czas > 120 & GPS < 9) |
                                          (klasa1 == 'PIE' & (GPS < 7 & (dystans_gps > dop_dystans_pieszy | predkosc_gps < v_max_pieszy))) | 
                                          (klasa1 == 'PIE' & predkosc_gps < v_max_pieszy & flagaAzymut == 1 & dystans_gps > dop_dystans_pieszy & flagaGPS == 1), 'B', 'NB')) 
  
    for (i in seq(nrow(tab))){
      
      if(isTRUE(tab[i,]$klasa1 == 'POJ')) {stan <- c(stan, 'Q1')}
      else if (isTRUE(tab[i,]$klasa1 == 'PIE' & tab[i,]$klasa2 == 'NB')) {stan <- c(stan, 'Q2')}
      else {stan <- c(stan, 'Q3')}
    }
    
    tab["stan"] <- "NA"
    tab$stan <- stan
    
    for (i in seq(nrow(tab))){
      
      if(tab[i,]$stan == 'Q1') {color <- c(color, "green")}
      else if (tab[i,]$stan == 'Q2') {color <- c(color, "blue")}
      else {color <- c(color, "red")}
    }
    
    tab["color"] <- "NA"
    tab$color <- color
    
    tab <<- tab
    
    td <- filter(tab, flagaAzymut != 'NA')
    td1 <<- filter(td, (klasa1 == 'POJ' & klasa2 == 'NB') | (klasa1 == 'PIE' & klasa2 == 'NB'))
    
 
    output$tab <- DT::renderDataTable(
      tab,
      extensions = c('ColReorder', 'FixedHeader'),
      options = list(
        pageLength = 100,
        colReorder = TRUE,
        fixedHeader = TRUE
      ) 
    ) 
    
    
    x <- c(1:nrow(tab))
    y <- tab$zmiana_azymut
    gucio <- rep(0, window/2)
    procenty <<- c(gucio, procent, gucio)
    
    data <- data.frame(x, tab$zmiana_azymut, procenty)
    ay3 <- list(
      tickfont = list(color = "black"),
      overlaying = "y",
      side = "right",
      title = "częstość zmiany azymutu [%]"
    )
    output$plot5 <- renderPlotly({
      plot_ly(data, x = ~x, y = ~y, name = 'zmiana azymutu', type = 'scatter', mode = 'lines+markers', line = list(width=2), color=I("green")) %>%
        add_trace(y = ~60, name = 'próg 60%', color = I("red"), mode='lines', line = list(dash = "dash", width=2),  yaxis = "y2") %>%
        #add_annotations(x = 10, y = 100, text='60%', color = '#ff0000') %>%
        add_trace(x = ~x, y = ~procenty, mode = 'lines', name = "częstość zmiany azymutu o więcej niż 15 stopni [%]", yaxis = "y2", color=I("orange")) %>%
        layout(
          margin = list(l = 50, r = 50, b = 50, t = 50, pad = 4),
          legend = list(orientation = 'h', x=0, y=-0.25),
          xaxis = list(title = "index obserwacji", showgrid = TRUE, showline = FALSE),
          yaxis = list(title = "zmiana azymutu [°]", showgrid = TRUE, showline = FALSE),
          yaxis2 = ay3)
    })
    
    y1 <- tab$GPS
    yy1 <- c(gucio, srodkowe_gps, gucio)
    mm <- c(gucio, mediany_gps, gucio)
    data <- data.frame(x, y1, yy1, mm)
    tekst <- paste('min = ', y1[which.min(y1)])
    ay1 <- list(
      tickfont = list(color = "black"),
      overlaying = "y",
      side = "right",
      title = "wartość mediany"
    )
    output$plot4 <- renderPlotly({
      plot_ly() %>%
        add_trace(x = ~x, y = ~tab$GPS, name = "liczba satelitów", mode = 'lines+markers', color=I('green')) %>%
        add_trace(x = ~x, y = ~mm, name = "wartość mediany", mode = 'lines+markers', yaxis = "y2", color=I('red')) %>%
        layout(
          margin = list(l = 50, r = 50, b = 50, t = 50, pad = 4),
          legend = list(orientation = 'h', x=0, y=-0.23),
          xaxis = list(title = "index obserwacji", showgrid = TRUE, showline = FALSE),
          yaxis = list(title = "liczba satelitów", showgrid = TRUE, showline = FALSE),
          title = "", yaxis2 = ay1
        )
    })
    
    
    
    y2 <- tab$predkosc_gps
    data <- data.frame(x, y2)
    
    output$plot2 <- renderPlotly({
      plot_ly(data, x = ~x, y = ~y2, name = 'prędkość GPS', type = 'scatter', mode = 'lines+markers', line = list(width=2), color=I("green")) %>%
        add_trace(y = ~2, name='próg 2[m/s]', mode = 'lines', line = list(dash = "dash", width=2), color = I("red")) %>%
        #add_annotations(x = 17, y = 2.4, text='2 [m/s]', color = I("red")) %>%
        layout(legend = list(orientation = 'h', x=0, y=-0.23),
               xaxis = list(title = "index obserwacji", showgrid = TRUE, showline = FALSE),
               yaxis = list(title = "prędkość [m/s]", showgrid = TRUE, showline = FALSE))
    })
    
    y3 <- tab$dystans_gps
    dop <- tab$dop_dystans
    data <- data.frame(x, y3, dop)
    tekst2 <- paste("max = ", dop[which.max(dop)], 'm')

    ay <- list(
      tickfont = list(color = "black"),
      overlaying = "y",
      side = "right",
      title = "dopuszczalny dystans pieszego [m]"
    )
   output$plot1 <- renderPlotly({
   plot_ly() %>%
      add_trace(x = ~x, y = ~tab$dop_dystans, name = "dopuszczalny dystans pieszego", mode = 'lines+markers', yaxis = "y2", color=I("pink")) %>%
      add_trace(x = ~x, y = ~tab$dystans_gps, name = "dystans GPS", mode = 'lines+markers', color=I("blue")) %>%
      #add_annotations(x = which.max(dop), y = dop[which.max(dop)], text = tekst2, color = '#ff0000', yaxis = "y2") %>%
       layout(
        margin = list(l = 50, r = 50, b = 50, t = 50, pad = 4),
        legend = list(orientation = 'h', x=0, y=-0.23),
        xaxis = list(title = "index obserwacji", showgrid = TRUE, showline = FALSE),
        yaxis = list(title = "dystans [m]", showgrid = TRUE, showline = FALSE),
        title = "", yaxis2 = ay
      )
   })
    
    y4 <- tab$roznica_czas
    pp <- tab$predkosc_gps
    sat <- tab$GPS
    data <- data.frame(x, y4, pp)
    tekst3 <- paste('max = ', y4[which.max(y4)], "s")
    
    output$plot3 <- renderPlotly({
      plot_ly(data, x = ~x, y = ~ y4, name = 'różnica czasu [s]', type = 'scatter', mode = 'lines+markers', line = list(width=2), color=I("blue")) %>%
        add_annotations(x = which.max(y4), y = y4[which.max(y4)], text = tekst3, color = '#ff0000') %>%
        layout(legend = list(orientation = 'h'), paper_bgcolor='rgb(255,255,255)',
               xaxis = list(title = "index obserwacji", showgrid = TRUE, showline = FALSE),
               yaxis = list(title = "różnica czasu [s]", showgrid = TRUE, showline = FALSE))
    })
    
    output$map = renderLeaflet({
      leaflet() %>%
        addTiles() %>%
        addScaleBar(position = "bottomright") %>%
        addPolylines(
          lng = unlist(tab$Lon),
          lat = unlist(tab$Lat),
          col = "red",
          opacity=0.8
        )
    })
    
    
  })
  
  
  observeEvent(input$button2, {
    
    output$tab <- DT::renderDataTable(
      td1,
      extensions = c('ColReorder', 'FixedHeader'),
      options = list(
        pageLength = 100,
        colReorder = TRUE,
        fixedHeader = TRUE
      ) 
    )
    
    output$map = renderLeaflet({
      leaflet() %>%
        addTiles() %>%
        addScaleBar(position = "bottomright") %>%
        addCircles(
          lng = unlist(tab$Lon),
          lat = unlist(tab$Lat),
          radius = 5,
          fillOpacity=1,
          opacity=1,
          color = tab$color) %>%
        addPolylines(
          lng = unlist(td1$Lon),
          lat = unlist(td1$Lat),
          color = 'black')
    })
  })
  
  observeEvent(input$button3, {
    
    output$map = renderLeaflet({
      leaflet() %>%
        addTiles() %>%
        addScaleBar(position = "bottomright") %>%
        addPolylines(
          lng = unlist(tab$Lon),
          lat = unlist(tab$Lat),
          color = 'red',
          opacity = 0.8
        ) %>%
        addPolylines(
          lng = unlist(td1$Lon),
          lat = unlist(td1$Lat),
          color = 'black',
          opacity = 0.8
        )
    })
    
    
  })
  
}

shinyApp(ui, server)