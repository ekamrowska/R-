
MedianslideFunction <- function(data, window, step){
  
  window <- window - 1
  total <- length(data)
  spots <- seq(from=1, to=(total-window), by=step)
  result <- vector(length = length(spots))
  ciagi <- vector(length = length(window))

for(i in 1:length(spots)){

    ciagi <- data[spots[i]:(spots[i]+window)]
    result[i] <- median(ciagi)
  
    #print(ciagi)
}
 return(result)

}


# mediany <- c()
# window <- 10
# 
# for(i in 1:(length(dane) - window + 1))  {
#   
#   mediany <- c(mediany, median(dane[i:(i+window-1)]))
#   
# }
