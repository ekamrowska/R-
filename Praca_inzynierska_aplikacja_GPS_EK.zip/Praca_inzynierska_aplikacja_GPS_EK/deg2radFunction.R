
deg2rad <- function(deg) {(deg * pi) / (180)}


