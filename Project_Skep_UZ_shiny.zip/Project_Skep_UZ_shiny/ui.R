library(shiny)
library(DT)
library(XML)
library(RCurl)
library(pracma)

shinyUI(
    
    navbarPage(
        title = 'System SKEP',
        tabPanel('Pracownicy', dataTableOutput('tab1')),
        tabPanel('Publikacje', dataTableOutput('tab2'))
        
        #numericInput("id_pracownik", "Podaj ID pracownika", 10, min = 1),
        #tabPanel('XYZ', dataTableOutput('tab3'))
        
    )
    
)

