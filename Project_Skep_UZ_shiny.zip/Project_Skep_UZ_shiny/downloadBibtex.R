library(XML)
library(RCurl)

downloadBibtex <- function(ulrPart){
  
    errorFrame <- function(){
        return(data.frame(
            id = gsub("\\D+","", gsub("wp_jezyk=1","", ulrPart)),
            authors = "Error",
            title = "Error",
            info = "Error"
        ))
    }

    url <- paste("http://publikacje.uz.zgora.pl:7777/skep/", ulrPart, sep = "")
    print(url)
    content <- getURL(url)
    content <- unlist(strsplit(content, '@.+:[0-9]{4},<br>'))  # rozdzielenie content .+ dowolny niezerowy ci�g znak�w,  [0-9]{4} cztery dowolne liczby
                                                               #  zacznij od np. @article{Adamczewski:2015,<br>
    if(length(content)<2){
        return(errorFrame())
    }

    content <- unlist(strsplit(content[[2]], '",<br>}'))    ##
    if(length(content)<2){
        return(errorFrame())
    }

    content <- paste('<p>', content[[1]], '"</p>', sep = "")   #  wk�ada w akapit 
    content <- gsub(',<br>','</p><p>', content)    # zamien enter <br> na akapity 
    pagetree <- htmlTreeParse(content, useInternal = TRUE)    # content -> html (DOM) 
    infos <- unlist(xpathApply(pagetree, '//p', xmlValue))  # wyszukaj wszystkie akapity 
    infos <- unlist(lapply(1:length(infos), function(i) {
        info <- unlist(strsplit(infos[[i]], '= "'))    # bibtex rozdzielamy = 
        if(length(info)==2){
          
            return(gsub('(^")|("$)','', info[[2]]))          #  ^" usun pierwszy cudzyslow, "$ usu� ostatni
        }
    }))

    print(infos)
    return(data.frame(
        id = gsub("\\D+","", gsub("wp_jezyk=1","", ulrPart)),
        authors = gsub(' and ',', ', infos[[1]]),
        title = infos[[2]],
        info = paste(unlist(infos[3:length(infos)]), collapse=', ')
    ))
}
