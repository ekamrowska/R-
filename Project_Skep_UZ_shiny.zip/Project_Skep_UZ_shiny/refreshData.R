source("downloadEmployees.R")
source("downloadEmployeeInfo.R")
source("downloadEmployeePublications.R")
source("downloadBibtex.R")
source("saveCSV.R")

refreshData <- function(){
    iterationStepLog <- function(part, partCount, i, count) {
        print(gettextf("[Part %d/%d][%7d / %d][%6.2f%%]", part, partCount, i, count, 100.0 * i/count))
    }

    iterationStepLog(1, 4, 1, 1)
    tmpEmployees <- downloadEmployees()
    
    numberOfEmployees <- nrow(tmpEmployees)
    for(i in 1: numberOfEmployees) {
    # for(i in 1:5) {
        iterationStepLog(2, 4, i, numberOfEmployees) #wy�wietlam post�p
        employees <- rbind(employees, downloadEmployeeInfo(tmpEmployees[i,])) #do��czanie danych: unit i department do nowej tabeli pracownik�w
    }
    
    tmpPublications <- data.frame()
    numberOfEmployees <- nrow(employees)
    for(i in 1: numberOfEmployees) {
    # for(i in 1:5) {
        iterationStepLog(3, 4, i, numberOfEmployees)
        tmpPublications <- rbind(tmpPublications, downloadEmployeePublications(employees[i,'id']))
    }
    authors <- tmpPublications[,c('id', 'author')]
    tmpPublications <- tmpPublications[!duplicated(tmpPublications[,'id']),] # usu� wiersze z powtarzaj�cym si� id publikacji   

    numberOfPublications <- nrow(tmpPublications)
    for(i in 1: numberOfPublications) {
    # for(i in 1:150) {
        iterationStepLog(4, 4, i, numberOfPublications)
        publications <- rbind(publications, downloadBibtex(tmpPublications[i, 'href']))
    }

    saveCSV(employees, "Employees.csv")
    saveCSV(authors, "Authors.csv")
    saveCSV(publications, "Publications.csv")
}
