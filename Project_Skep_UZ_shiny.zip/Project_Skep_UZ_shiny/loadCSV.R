library(csv)

loadCSV <- function(fileName){
    if (file.exists(fileName)) {
        return(read.csv(fileName, encoding = 'UTF-8'))
    }
    return(data.frame())
}
