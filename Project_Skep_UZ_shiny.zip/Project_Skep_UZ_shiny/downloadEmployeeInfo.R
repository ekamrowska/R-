library(XML)
library(RCurl)

#downloadEmployeeInfo(employees[x,]) #x to numer wiersza pracownika

downloadEmployeeInfo <- function(employee){
  
    url <- paste("http://publikacje.uz.zgora.pl:7777/skep/show.select_period?wp_pracownik_id=", employee[1,'id'], "&wp_jezyk=1", sep = "")
    print(url)
    content <- getURL(url)
    pagetree <- htmlTreeParse(content, useInternalNodes = TRUE)
    
    nodes <- getNodeSet(pagetree, "//*/tr[./td[@class='Wybor_wartosc']]")           # * gdziekolwiek, tr wiersz, td kom�rka   . bezpo�rednio w �rodku
    values <- lapply(nodes, xpathSApply, "./td[@class='Wybor_wartosc']", xmlValue)

    values <- unlist(lapply(1:3, function(i) {
        value <- values[[i]]
        value <- unlist(strsplit(value, '\n'))
        
        if(length(value)>1){
            return(value[2])
        }
        
    }))
    
    #print(values)
    return(data.frame(
        id = employee[1,'id'],
        name = employee[1,'name'],
        title = employee[1,'title'],
        job = employee[1,'job'],
        department = values[1],
        unit = values[2]
        
    ))
}
