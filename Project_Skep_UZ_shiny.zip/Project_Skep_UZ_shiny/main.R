source("refreshData.R")
source("loadCSV.R")
library(pracma)

employees <- loadCSV("Employees.csv")
authors <- loadCSV("Authors.csv")
publications <- loadCSV("Publications.csv")

if(nrow(authors) == 0) {
    refreshData()
}


# PUBLIKACJE DUCHY 
#publicationsErrors <- publications[is.element(publications$title, c("Error")),'id']  
#authorsErrors <- authors[authors$id%in%publicationsErrors, 'author']
#employeesError <- employees[employees$id%in%authorsErrors,]
