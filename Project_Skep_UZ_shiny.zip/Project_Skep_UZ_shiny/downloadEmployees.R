library(XML)
library(RCurl)

downloadEmployees <- function(){
    url <- "http://publikacje.uz.zgora.pl:7777/skep/show.authors?wp_jezyk=1"
    print(url)
    content <- getURL(url)
    content <- gsub("Autorzy_dydatyczni_[a-zA-Z]","Autorzy_dydatyczni", content)   #[a-zA-Z]  jakikolwiek znak od a do z lub A  do Z
    pagetree <- htmlTreeParse(content, useInternalNodes = TRUE)
    
    nodes <- getNodeSet(pagetree, "//*/tr[./td[@class='Autorzy_dydatyczni']]")
    
    titles <- lapply(nodes, xpathSApply, "./td[2]", xmlValue)
    names <- lapply(nodes, xpathSApply, "./td[3]", xmlValue)
    hrefs <- lapply(nodes, xpathSApply, "./td[3]/a", xmlGetAttr, 'href')
    jobs <- lapply(nodes, xpathSApply, "./td[4]", xmlValue)
    
    count <- length(titles)
    ids <- lapply(1:count, function(i) gsub("\\D+", "", gsub("&wp_jezyk=1","", hrefs[[i]]))) #D wszystko co nie jest liczb�, + musi wyst�pi� conajmniej raz
    
    return(data.frame(
        id = unlist(ids),
        name = unlist(names),
        title = unlist(titles),
        job = unlist(jobs)
    ))
}
