
getPublicationList <- function(id){
  
    #autorIdList <- subset(authors, author==id, select='id')
  
    autorIdList <- authors[authors$author==id,'id']            # wyci�ga id wszystkich publikacji konkretnego autora
    publicationList <- publications[publications$id%in%autorIdList,]
    
    #print(autorIdList)
    return(publicationList)
    
    
}

