library(shiny)
library(DT)

source("main.R")
source("getPublicationList.R")


shinyServer(

    function(input, output) {
      
        output$tab1 <- renderDataTable(employees[-1], selection = "single",
            options = list(
                lengthMenu = list(c(5, 15, -1), c('5', '15', 'All')),
                pageLength = 15
            )
        )
        
        output$tab2 = renderDataTable({
            index = input$tab1_rows_selected
            getPublicationList(employees[index,'id'])[-1]
        }, selection = "none")
        # }, selection = "single")
    }    
)

