library(XML)
library(RCurl)

downloadEmployeePublications <- function(employeeId){
    url <- paste("http://publikacje.uz.zgora.pl:7777/skep/show.publications_author?wp_pracownik_id=", employeeId, "&wp_jezyk=1", sep = "")
    print(url)
    content <- getURL(url)
    content <- gsub("href *= *\"publications_format_bib","class=\"BibTeX\" href=\"publications_format_bib", content)
    pagetree <- htmlTreeParse(content, useInternalNodes = TRUE)
    nodes <- getNodeSet(pagetree, "//*/td[@class=\"Dane_publikacji\"][./a[@class=\"BibTeX\"]]")
     
    hrefs <- lapply(nodes, xpathSApply, "./a[@class=\"BibTeX\"]", xmlGetAttr, 'href')
    
    numberOfPublications <- length(hrefs)
    
    if (numberOfPublications > 0) {
        titles <- lapply(nodes, xpathSApply, "./b", xmlValue)
        titles <- lapply(1:numberOfPublications, function(i) {
            a = titles[[i]]
            if(length(a)>0){
                return(a[1])
            }
        })
        
        ids <- lapply(1:numberOfPublications, function(i) gsub("\\D+","", gsub("wp_jezyk=1","", hrefs[[i]] )))
        return(data.frame(
            id = unlist(ids),
            author = unlist(rep(employeeId, numberOfPublications)),
            title = unlist(titles),
            href = unlist(hrefs)
        ))
    }
}
