library(csv)

saveCSV <- function(frame, file){ 
    write.csv(frame, file, row.names = FALSE)
}
