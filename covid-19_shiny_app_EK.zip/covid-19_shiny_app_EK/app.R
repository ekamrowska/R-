source('covid.R')

library(shiny)
library(leaflet)
library(htmltools)

r_colors <- rgb(t(col2rgb(colors()) / 255))
names(r_colors) <- colors()

# ui <- fluidPage(
#   leafletOutput("mymap"),
#   p()
# )

ui <- fluidPage(
  title = "COVID-19 Global Cases",
  tags$style(type = "text/css", ".container-fluid {padding-left: 0px; padding-right: 0px !important;}"),
  tags$style(type = "text/css", ".navbar {margin-bottom: 0px;}"),
  tags$style(type = "text/css", ".content {padding: 0px;}"),
  tags$style(type = "text/css", ".row {margin-left: 0px; margin-right: 0px;}"),
  tags$style(HTML(".col-sm-12 { padding: 5px; margin-bottom: -15px; }")),
  tags$style(HTML(".col-sm-6 { padding: 5px; margin-bottom: -15px; }")),
  navbarPage(
    title = div("COVID-19 Global Cases", style = "padding-left: 10px"),
    collapsible = TRUE,
    fluid = TRUE,
    tabPanel("World map", leafletOutput("mymap")),
    tabPanel("Table",
             fluidPage(
               fluidRow(column(4,
                               selectInput(
                                 "select3",
                                 label = h5("Select country:"),
                                 choices = country_list
                               )))),
             DT::dataTableOutput('table2')),
    tabPanel("Plots",
             fluidPage(
               fluidRow(column(4,
             selectInput(
               "select1",
               label = h5("Select country:"),
               choices = country_list
             )))),
             fluidPage(
               fluidRow(column(4,
                               selectInput(
                                 "select2",
                                 label = h5("Select data start:"),
                                 choices = data_start
                               )))),
             plotOutput("plot")
    )
  )
)

server <- function(input, output, session) {
  
  output$mymap <- renderLeaflet({
    leaflet() %>%
      addProviderTiles(providers$Stamen.TonerLite,
                       options = providerTileOptions(noWrap = TRUE)
      ) %>%
      addCircleMarkers(lng = temp0$longitude, 
                       lat = temp0$latitude,
                       radius = findInterval(temp0$total_confirmed,c(10^4, 10^6, 10^9)) * 4,
                       color = 'red',
                       label = lapply(labs, htmltools::HTML),
                       stroke = FALSE, fillOpacity = 0.5)
  })
  
  tab <- reactive({ 
    x %>% 
      select(administrative_area_level_1, date, tests, confirmed, recovered, deaths) %>% 
      filter(administrative_area_level_1 == input$select1) %>% 
      filter(date >= input$select2) %>% 
      select(-administrative_area_level_1)
    
  })
  
  output$table <- renderTable({ 
    
    tab()
  })
  
  
  tab2 <- reactive({ 
    x %>% 
      select(administrative_area_level_1, date, tests, confirmed, recovered, deaths) %>% 
      filter(administrative_area_level_1 == input$select3) %>% 
      rename(Country = administrative_area_level_1)
  })
  
  output$table2 <- DT::renderDT({ 
    
    tab2()
  })
  
  
  output$plot <- renderPlot({
    
    X <- melt(tab(), id.vars="date")
    gg <- ggplot(X, aes(date,value)) +
      geom_point() +
      stat_smooth(color = 'red') +
      facet_wrap(.~variable, scales = 'free_y', ncol=2) +
      theme_bw() +
      scale_y_continuous(labels = scales::comma) + 
      labs(x = 'Date', 
           y = 'Value')
    gg
  })
}

shinyApp(ui, server)