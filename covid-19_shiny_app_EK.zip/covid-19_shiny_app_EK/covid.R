library(COVID19)
library(tidyverse)
library(reshape2)

x <- covid19(
  country = NULL,
  level = 1,
  start = "2010-01-01",
  end = Sys.Date(),
  raw = TRUE,
  vintage = FALSE,
  verbose = TRUE,
  cache = TRUE,
  wb = NULL,
  gmr = NULL,
  amr = NULL
) %>% 
  ungroup() 

temp0 <- x %>% select(administrative_area_level_1,
                      latitude,
                      longitude, 
                      tests, 
                      confirmed,
                      recovered, 
                      deaths,
                      population) %>% 
  na.omit() %>% 
  group_by(administrative_area_level_1, latitude, longitude, population) %>% 
  summarise(total_tests = sum(tests), 
            total_confirmed = sum(confirmed),
            total_recovered = sum(recovered),
            total_deaths = sum(deaths)) %>% 
  ungroup()


labs <- lapply(seq(nrow(temp0)), function(i) {
  paste0('<p>', temp0[i, "administrative_area_level_1"], '<p></p>', 
         'Population: ', temp0[i, "population"],'</p><p>', 
         'Total tests: ', temp0[i, "total_tests"],'</p><p>', 
         'Total confirmed: ', temp0[i, "total_confirmed"],'</p><p>', 
         'Total recovered: ', temp0[i, "total_recovered"],'</p><p>',
         'Total deaths: ', temp0[i, "total_deaths"],'</p>')
})

country_list <- temp0 %>%
  select(administrative_area_level_1)

data_start <- x %>% 
  select(date) %>% 
  mutate(date = lubridate::floor_date(date, unit = 'months')) %>% 
  distinct()

